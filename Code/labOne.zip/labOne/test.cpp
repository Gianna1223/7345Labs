#include <iostream>
#include <ctime>
#include <vector>
#include <string>
using namespace std;

int trap(vector<int> &height)
{
    int left = 0;
    int right = height.size() - 1;
    int left_bar_max = 0;
    int right_bar_max = 0;
    int ans = 0;
    //左指针、右指针重合跳出循环返回答案
    while (left < right)
    {
        //左边高度小于右边高度，便从左到右遍历
        if (height[left] < height[right])
        {
            //左指针高度大于左边最大高度，将左边最大高度更新成左指针指向的高度
            if (height[left] > left_bar_max)
            {
                left_bar_max = height[left];
            }
            else
            {
                ans += left_bar_max - height[left];
            }
            left++;
        }
        else
        {
            if (height[right] > right_bar_max)
            {
                right_bar_max = height[right];
            }
            else
            {
                ans += right_bar_max - height[right];
            }
            right--;
        }
    }
    return ans;
}

int main()
{
    clock_t startTime, endTime;
    startTime = clock(); //计时开始
    //vector<int> a(3,1,2,5,2,4);
    int n[] = {592,401,874,141,348,72,91,887,820,283} ;
    vector<int> a(n, n+10);
    trap(a);
    endTime = clock(); //计时结束
    cout << "The run time is:" << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
    system("pause");
    return 0;
}